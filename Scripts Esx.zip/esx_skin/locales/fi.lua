Locales['fi'] = {
  ['skin_menu'] = 'ulkonäkö',
  ['use_rotate_view'] = 'paina ~INPUT_VEH_FLY_ROLL_LEFT_ONLY~ tai ~INPUT_VEH_FLY_ROLL_RIGHT_ONLY~ liikutaaksesi kameraa.',
  ['skin'] = 'vaihda ulkonäköä',
  ['saveskin'] = 'talleta ulkonäkö tiedostoon',
}
