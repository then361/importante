Locales['en'] = {
  ['skin_menu'] = 'Menu de apariencia',
  ['use_rotate_view'] = 'Usa  ~INPUT_VEH_FLY_ROLL_LEFT_ONLY~y   ~INPUT_VEH_FLY_ROLL_RIGHT_ONLY~para rotar la vista.',
  ['skin'] = 'Cambio de apariencia',
  ['saveskin'] = 'Guardar apariencia en la base de datos',
}
